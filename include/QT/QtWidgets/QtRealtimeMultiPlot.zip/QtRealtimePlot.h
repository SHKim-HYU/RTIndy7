#pragma once

#include <QDialog>
#include <QDateTime>
#include <QTimer>
#include <QLabel>
#include <QButtonGroup>
#include <QComboBox>
#include "QtChartViewer.h"
#include <vector>

class QRealTimePlot : public QWidget {
    Q_OBJECT
public:
    QRealTimePlot(QWidget *parent = 0);
    ~QRealTimePlot();

private:
    std::vector<double> m_timeStamps;	// The timestamps for the data series
    std::vector<double> m_dataSeriesA;	// The values for the data series A
    std::vector<double> m_dataSeriesB;	// The values for the data series B
    std::vector<double> m_dataSeriesC;	// The values for the data series C

    QDateTime m_nextDataTime;           // Used by the random number generator to generate realtime data.

    QChartViewer *m_ChartViewer;        // QChartViewer control
    //QTimer *m_ChartUpdateTimer;         // The chart update timer

    void resizeEvent(QResizeEvent *);
   
    int m_width;
    int m_height;
public:
    void setSize(int width, int height);        
    QTimer* m_ChartUpdateTimer;         // The chart update timer

private slots:
    void onRunFreezeChanged(QAbstractButton *b);    // The "Run" or "Freeze" button has been pressed
    void onUpdatePeriodChanged(int);                // The chart update timer interval has changed.
    void getData();                                 // Get new data values
    void updateChart();                             // Update the chart.
    void drawChart();                               // Draw the chart.
};

